# 代码说明

`traditional-layout.html` 和 `traditional-layout.css` 是文档任务的示例代码，大家可以在浏览器中打开`traditional-layout.html`，查看布局效果；
